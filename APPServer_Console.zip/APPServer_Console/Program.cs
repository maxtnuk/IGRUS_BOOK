﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Net.Sockets;

namespace APPServer_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            Socket serversocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serversocket.Bind(new IPEndPoint(IPAddress.Parse("192.168.43.43"), 7777));
            serversocket.Listen(100);
            Socket clientsocket = serversocket.Accept();
            Console.WriteLine(clientsocket.RemoteEndPoint);
            byte[] data = new byte[2048];

            int recv = clientsocket.Receive(data, 0, data.Length, SocketFlags.None);
            if (recv < data.Length)
            {
                byte[] temp = new byte[recv];
                for (int i = 0; i < temp.Length; i++)
                {
                    temp[i] = data[i];
                }

                data = new byte[temp.Length];
                for (int i = 0; i < data.Length; i++)
                {
                    data[i] = temp[i];
                }
            }

            string message = Encoding.Default.GetString(data);

            string[] json = message.Split(',');
            foreach (string key_value in json)
            {
                string[] temp = key_value.Split(':');
                dictionary.Add(temp[0], temp[1]);
            }

            foreach (KeyValuePair<string, string> temp in dictionary)
            {
                Console.WriteLine(temp.Key + " : " + temp.Value);
            }
        }
    }
}